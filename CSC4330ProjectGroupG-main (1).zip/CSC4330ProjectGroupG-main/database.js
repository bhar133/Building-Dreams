import mysql from 'mysql2'
import jwt from 'jsonwebtoken'
import dotenv from 'dotenv'
dotenv.config()

export const db = mysql.createConnection({
    host: process.env.HOST_HOST,
    //host: '127.0.0.1',
    user: process.env.MYSQL_USER,
    //user: 'root',
    password: process.env.MYSQL_PASSWORD,
    //password: '',
    database: process.env.MYSQL_DATABASE
    //database: 'pc_parts'
})
db.connect((err) => {
    if (err) {
      console.error('Error connecting to MySQL:', err);
      return;
    }
    console.log('Connected to MySQL');
  });
//part functions


// export async function getParts(){
//     const [rows] = await bd.query('SELECT * FROM parts')
//     return rows
// }

// export async function getPart(id){
//     const [rows] = await bd.query('SELECT * FROM parts WHERE id = ?', [id])
//     return rows[0]
// }

// export async function getSelectedPart(part_type){
//     const [rows] = await bd.query('SELECT part_name FROM parts WHERE part_type = ? AND is_part_selected = 1',[part_type])
//     return rows[0]
// }

// export async function addPart(part_name, part_type, price, contents, stock, avalibility, is_part_selected, specs ) {
//     const result = await bd.query('INSERT INTO parts (part_name, part_type, price, contents, stock, avalibility, is_part_selected, specs) VALUES (?, ?, ?, ?, ?, ?, ?, ?)', 
//     [part_name, part_type, price, contents, stock, avalibility, is_part_selected, specs])
//     return result
// }



// //user functions

// export async function getUsers(){
//     const [rows] = await bd.query('SELECT * FROM users')
//     return rows
// }

//  export async function getUser(id){
//      const [rows] = await bd.query('SELECT * FROM users WHERE id = ?', [id])
//      return rows[0]
//  }

// export async function getUsername(){
//     const [rows] = await bd.query('SELECT user_name FROM users WHERE signed_in = 1')
//     return rows[0]
// }

// export async function addUser(user_name, user_password, user_number, card_num, card_date, card_CVV, signed_in ) {
//     const result = await bd.query('INSERT INTO users (user_name, user_password, user_number, card_num, card_date, card_CVV, signed_in) VALUES (?, ?, ?, ?, ?, ?, ?)', 
//     [user_name, user_password, user_number, card_num, card_date, card_CVV, signed_in])
//     return result
// }

export const register = (req, res)=> {

    //check if user exists

    const q =  'SELECT * FROM users WHERE username = ?';

    db.query(q, [req.body.username], (err, data)=>{
        if(err) return res.status(500).json(err)
        if (data.length) return res.status(409).json("User already exists")

        //create a new user
        //password is in a const for now becasue if we are going to hash it need to be like this
        const values = [
            req.body.username,
            req.body.password,
            req.body.number,
          ];
        //const password = (req.body.password)
        //const confPassword = (req.body.confirmpassword)

       

        
        const user = 'INSERT INTO users (username, password, number ) VALUE (?);';

        db.query(user,[values], (err,data)=>{
            if (err) return res.status(500).json(err)
            return res.status(200).json("User has been created.")
        })
    })
    
}

export const login = (req, res) => {

    const q = "SELECT * FROM users WHERE username = ?;";

    db.query(q, [req.body.username], (err,data)=>{
        if (err) return res.status(500).json(err);
        if (data.length === 0) return res.status(404).json("user not found!")

        const checkPassword = (req.body.password == data[0].password)

        if(!checkPassword) return res.status(400).json("Wrong password or username!")

        const token = jwt.sign({id:data[0].id}, "secretkey")

        const {password, ...others} = data[0]

        res.cookie("accessToken", token, {
            httpOnly: true,
        })
        .status(200)
        .json(others)
    })
}
export const logout = (req, res) => {
    res.clearCookie("accessToken",{
    secure:true,
    sameSite:"none"
    }).status(200).json("User has been logged out")
}   
