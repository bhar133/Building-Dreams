import React from "react";
import "./ProductDetails.css"; // Import your stylesheet

function ProductDetails(props) {
  const {
    id,
    partName = "Unknown Part",
    price = 0,
    brand = "Unknown Brand",
    description = "No description available",
    partType,
    imageUrl = "",
    wattage = null,
    wattage_delivered = null,
    socket = null,
    size = null,
    onAddToCart,
    onAddToBuild,
  } = props;

  const handleAddToCart = () => {
    // Call the function passed from the parent component to add the item to the cart
    onAddToCart({
      id,
      partName,
      price,
      brand,
      description,
      partType,
      imageUrl,
      wattage,
      wattage_delivered,
      socket,
      size,
    });
  };
  const handleAddToBuild = () => {
    // Call the function passed from the parent component to add the item to the cart
    onAddToBuild({
      id,
      partName,
      price,
      brand,
      description,
      partType,
      imageUrl,
      wattage,
      wattage_delivered,
      socket,
      size,
    });
  };

  return (
    <div className="containerproducts">
      <div className="white-box">
        <img src={imageUrl} style={{ width: "250px", height: "auto" }} />
      </div>
      <div className="part">
        <div>{partName}</div>
      </div>
      <div className="part">
        <div>${price}</div>
      </div>
      <div className="part">
        <div>{description}</div>
      </div>
      <div className="button-container">
        <button className="add-button top" onClick={handleAddToCart}>
          Add to Cart
        </button>
        <button className="add-button bottom" onClick={handleAddToBuild}>
          Add to Build
        </button>
      </div>
    </div>
  );
}

export default ProductDetails;
