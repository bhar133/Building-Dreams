import React, { useEffect, activeTab, useState } from "react";
import Logo from "./Logo.png";
import Cart from "./Cart.png";
import ProductDetails from "./ProductDetails";
import "./PartSelector.css";
import { Link } from "react-router-dom";
import { key } from "localforage";
import Chatbox from "../Chatbox/Chatbox";
const PartSelector = () => {
  const [activeTab, setActiveTab] = useState("cpus");
  const [parts, setParts] = useState([]); // Initially empty, will be populated based on active tab

  //Asking to save build with name
  const [isModalOpen, setModalOpen] = useState(false);
  const [buildName, setBuildName] = useState("");

  const [cart, setCart] = useState(() => {
    const savedCart = localStorage.getItem("cart");
    return savedCart ? JSON.parse(savedCart) : [];
  });
  const [build, setBuild] = useState(() => {
    const savedBuild = localStorage.getItem("build");
    return savedBuild ? JSON.parse(savedBuild) : [];
  });
  const [savedBuilds, setSavedBuilds] = useState(
    JSON.parse(localStorage.getItem("savedBuilds")) || []
  );

  // Function to save a new build
  const saveBuild = (newBuild) => {
    const updatedBuilds = [...savedBuilds, newBuild];
    setSavedBuilds(updatedBuilds);
    localStorage.setItem("savedBuilds", JSON.stringify(updatedBuilds));
  };

  useEffect(() => {
    const fetchParts = async () => {
      try {
        const response = await fetch(
          `http://localhost:8800/parts/${activeTab}`
        );
        const data = await response.json();
        setParts(data.parts);
      } catch (error) {
        console.error("Error fetching parts:", error);
      }
    };

    fetchParts();
  }, [activeTab]);

  const handleTabClick = (tab) => {
    setActiveTab(tab);
    // Fetch and set parts based on the active tab (e.g., from database)
    // Example: fetchParts(tab);
    //fetchParts(tab);
  };
  const handleAddToCart = (item) => {
    const cartItem = {
      ...item,
      partName: item.part_name, // Assuming 'part_name' is the property name for the part name
    };
    setCart([...cart, item]);
  };
  const handleAddToBuild = (item) => {
    const buildItem = {
      ...item,
      partName: item.part_name, // Assuming 'part_name' is the property name for the part name
    };
    const hasType = build.some((person) => person.partType === item.partType);
    if (hasType) {
      alert("Part already in build");
    } else setBuild([...build, item]);
  };

  const handleRemoveFromCart = (index) => {
    const updatedCart = [...cart];
    updatedCart.splice(index, 1);
    setCart(updatedCart);
  };
  const handleRemoveFromBuild = (index) => {
    const updatedBuild = [...build];
    updatedBuild.splice(index, 1);
    setBuild(updatedBuild);
  };
  const handleClearCart = () => {
    setCart([]);
  };
  const handleClearBuild = () => {
    setBuild([]);
  };

  useEffect(() => {
    localStorage.setItem("cart", JSON.stringify(cart));
  }, [cart]);
  useEffect(() => {
    localStorage.setItem("build", JSON.stringify(build));
  }, [build]);

  const totalPrice = cart.reduce((acc, item) => acc + item.price, 0);

  const handleSaveBuild = () => {
    if (buildName) {
      const buildWithNames = { name: buildName, ...build };
      saveBuild(buildWithNames);
      alert("Build saved successfully!");
      setModalOpen(false); // Close modal after saving
      setBuildName(""); // Reset build name
      setBuild([]); // Clear the build data
    }
  };
  console.log(build);
  const buildCpus = build.filter((component) => component.partType === "cpus");
  const buildGpus = build.filter((component) => component.partType === "gpus");
  const buildMotherboards = build.filter(
    (component) => component.partType === "motherboards"
  );
  console.log(build.filter((component) => component.type === "motherboards"));
  const buildCases = build.filter(
    (component) => component.partType === "cases"
  );
  const buildStorage = build.filter(
    (component) => component.partType === "storage"
  );
  const buildMemory = build.filter(
    (component) => component.partType === "memory"
  );
  const buildPsus = build.filter((component) => component.partType === "psus");

  //The following code is for paginating the cart
  // Pagination state
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 5;
  const totalPages = Math.ceil(cart.length / itemsPerPage);

  // Calculate index range for current page
  const indexOfLastItem = currentPage * itemsPerPage;
  const indexOfFirstItem = indexOfLastItem - itemsPerPage;
  const currentItems = cart.slice(indexOfFirstItem, indexOfLastItem);

  // Change page
  const nextPage = () => {
    setCurrentPage(currentPage + 1);
  };

  const prevPage = () => {
    setCurrentPage(currentPage - 1);
  };

  return (
    <>
      <div className="page">
        <nav className="navbar">
          {/* Top row */}
          <div className="top-row">
            <img src={Logo} alt="Left Logo" className="leftlogo" />

            <div className="nav-links">
              <Link to="/ViewBuild">
                <button className="checkout-button">Saved Builds</button>
              </Link>
              <Link to="/CheckOut">
                <button className="checkout-button">
                  <img src={Cart} alt="Right Logo" />
                </button>
              </Link>
            </div>
          </div>

          {/* Bottom row */}
          <div className="bottom-row">
            <div>
              <button onClick={() => handleTabClick("cpus")}>CPUs</button>
              <button onClick={() => handleTabClick("motherboards")}>
                Motherboards
              </button>

              <button onClick={() => handleTabClick("gpus")}>GPUs</button>
              <button onClick={() => handleTabClick("memory")}>Memory</button>
              <button onClick={() => handleTabClick("storage")}>Storage</button>
              <button onClick={() => handleTabClick("cases")}>Case</button>
              <button onClick={() => handleTabClick("psus")}>PSU</button>
              {/* Add more buttons for other part types */}
            </div>
          </div>
        </nav>

        <div className="ProductBoxContainer">
          {parts &&
            parts.map((part) => (
              <ProductDetails
                key={part.id} // Don't forget to add a unique key when rendering arrays in React
                partName={part.part_name || "Unknown Part"}
                price={part.price || 0}
                description={part.contents || "No description available"}
                partType={activeTab}
                imageUrl={
                  "http://localhost:8800/uploads/" + (part.imagePath || "")
                }
                socket={part.socket || "Unknown Socket"}
                wattage={part.wattage ?? "Unknown Wattage"}
                wattageDelivered={
                  part.wattage_delivered ?? "Unknown Delivered Wattage"
                }
                size={part.size ?? "Unknown Size"}
                onAddToCart={handleAddToCart}
                onAddToBuild={handleAddToBuild}
              />
            ))}
        </div>
        <div className="cart-container">
          <div className="cart-header">Cart</div>
          {currentItems.map((item, index) => (
            <div className="cart-item" key={index}>
              <div className="item-text">{item.partName}</div>
              <div className="item-price">${item.price}</div>
              <button className="remove-button" onClick={handleRemoveFromCart}>
                Remove
              </button>
            </div>
          ))}
          <button onClick={handleClearCart}>Clear Cart</button>
          <div className="pagination">
            <button onClick={prevPage} disabled={currentPage === 1}>
              Prev
            </button>
            <span>
              {currentPage} / {totalPages}
            </span>
            <button onClick={nextPage} disabled={currentPage === totalPages}>
              Next
            </button>
          </div>
        </div>

        <div className="build-container">
          <div className="build-header">Build</div>
          {console.log(buildMotherboards)}
          {console.log(buildCpus)}
          {buildCpus.map((item) => (
            <div className="build-row" key={"0"}>
              <div className="build-text">{item.partName}</div>
              <div className="build-price">{item.price}</div>
              <button
                className="remove-button"
                onClick={() => handleRemoveFromBuild(key)}
              >
                Remove
              </button>
            </div>
          ))}
          {buildGpus.map((item) => (
            <div className="build-row" key={"1"}>
              <div className="build-text">{item.partName}</div>
              <div className="build-price">{item.price}</div>
              <button
                className="remove-button"
                onClick={() => handleRemoveFromBuild(key)}
              >
                Remove
              </button>
            </div>
          ))}
          {buildMotherboards.map((item) => (
            <div className="build-row" key={"2"}>
              <div className="build-text">{item.partName}</div>
              <div className="build-price">{item.price}</div>
              <button
                className="remove-button"
                onClick={() => handleRemoveFromBuild(key)}
              >
                Remove
              </button>
            </div>
          ))}
          {buildMemory.map((item) => (
            <div className="build-row" key={"3"}>
              <div className="build-text">{item.partName}</div>
              <div className="build-price">{item.price}</div>
              <button
                className="remove-button"
                onClick={() => handleRemoveFromBuild(key)}
              >
                Remove
              </button>
            </div>
          ))}
          {buildStorage.map((item) => (
            <div className="build-row" key={"4"}>
              <div className="build-text">{item.partName}</div>
              <div className="build-price">{item.price}</div>
              <button
                className="remove-button"
                onClick={() => handleRemoveFromBuild(key)}
              >
                Remove
              </button>
            </div>
          ))}
          {buildCases.map((item) => (
            <div className="build-row" key={"5"}>
              <div className="build-text">{item.partName}</div>
              <div className="build-price">{item.price}</div>
              <button
                className="remove-button"
                onClick={() => handleRemoveFromBuild(key)}
              >
                Remove
              </button>
            </div>
          ))}
          {buildPsus.map((item) => (
            <div className="build-row" key={"6"}>
              <div className="build-text">{item.partName}</div>
              <div className="build-price">{item.price}</div>
              <button
                className="remove-button"
                onClick={() => handleRemoveFromBuild(key)}
              >
                Remove
              </button>
            </div>
          ))}
          <button onClick={() => setModalOpen(true)}>Save Build</button>
          {isModalOpen && (
            <div
              style={{
                position: "absolute",
                top: "50%",
                left: "50%",
                transform: "translate(-50%, -50%)",
                background: "white",
                padding: "20px",
                zIndex: 100,
              }}
            >
              <input
                type="text"
                value={buildName}
                onChange={(e) => setBuildName(e.target.value)}
                placeholder="Enter build name"
              />
              <button onClick={handleSaveBuild}>Save</button>
              <button onClick={() => setModalOpen(false)}>Cancel</button>
            </div>
          )}
        </div>
        <Chatbox></Chatbox>
      </div>
    </>
  );
};

export default PartSelector;
