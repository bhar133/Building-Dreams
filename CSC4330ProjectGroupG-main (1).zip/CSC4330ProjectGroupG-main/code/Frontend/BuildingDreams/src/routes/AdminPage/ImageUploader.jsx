import React, { useState } from "react";
import axios from "axios";
import { useDropzone } from "react-dropzone";

const ImageUploader = () => {
  const [selectedTable, setSelectedTable] = useState("");
  const [image, setImage] = useState(null);
  const [id, setId] = useState("");

  const { getRootProps, getInputProps } = useDropzone({
    accept: ".jpg, .jpeg, .png",
    onDrop: (acceptedFiles) => {
      const file = acceptedFiles[0];
      setImage(file);
    },
  });

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      // Using FormData to handle file uploads along with other data
      const formData = new FormData();
      formData.append("image", image); // Append the image file
      formData.append("id", id); // Append the ID as a string
      formData.append("table", selectedTable); // Optional: If you want to send the table name in FormData
      formData.append("imageName", image.name); // Append the image name

      // Axios post request
      await axios.post(`http://localhost:8800/upload`, formData, {
        headers: {
          // "Content-Type": "multipart/form-data" is automatically set by Axios when using FormData
        },
      });

      alert("Image path added successfully!");
      setSelectedTable("");
      setImage(null);
      setId("");
    } catch (error) {
      console.error("Error adding image path:", error);
    }
  };

  return (
    <div>
      <h2>Add Image to Part</h2>
      <form onSubmit={handleSubmit}>
        <label htmlFor="tableSelect">Select Table:</label>
        <select
          id="tableSelect"
          value={selectedTable}
          onChange={(e) => setSelectedTable(e.target.value)}
        >
          <option value="">Select Table...</option>
          <option value="cpus">CPUs</option>
          <option value="gpus">GPUs</option>
          <option value="motherboards">Motherboards</option>
          <option value="storage">Storage</option>
          <option value="memory">Memory</option>
          <option value="psus">PSUs</option>
          <option value="cases">Cases</option>
        </select>

        <label htmlFor="id">Enter ID:</label>
        <input
          type="text"
          id="id"
          value={id}
          onChange={(e) => setId(e.target.value)}
        />

        <div
          {...getRootProps()}
          style={{
            border: "2px dashed #ccc",
            padding: "20px",
            marginTop: "20px",
          }}
        >
          <input {...getInputProps()} />
          <p>Drag 'n' drop an image here, or click to select an image</p>
        </div>

        {image && (
          <div>
            <h4>Selected Image:</h4>
            <img
              src={URL.createObjectURL(image)}
              alt="Selected"
              style={{ maxWidth: "100%", height: "auto" }}
            />
          </div>
        )}

        <button type="submit" disabled={selectedTable == null || !image || !id}>
          Submit
        </button>
      </form>
    </div>
  );
};

export default ImageUploader;
