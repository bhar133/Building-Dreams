import React, { useState } from "react";
import axios from "axios";
import { useDropzone } from "react-dropzone";
import ImageUploader from "./ImageUploader";
function AddPart() {
  const [partType, setPartType] = useState("");
  const [partName, setPartName] = useState("");
  const [price, setPrice] = useState("");
  const [contents, setContents] = useState("");
  const [stock, setStock] = useState("");
  const [wattage, setWattage] = useState("");
  const [socket, setSocket] = useState("");
  const [generation, setGeneration] = useState("");
  const [size, setSize] = useState("");
  const [ddrGen, setDdrGen] = useState("");
  const [cpuGenSupported, setCpuGenSupported] = useState("");
  const [wattageDelivered, setWattageDelivered] = useState("");
  const [image, setImage] = useState(null);
  const [previewUrl, setPreviewUrl] = useState();
  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    accept: ".jpg, .jpeg, .png",
    onDrop: (acceptedFiles) => {
      const file = acceptedFiles[0];
      setImage(file);

      const reader = new FileReader();
      reader.onloadend = () => {
        setPreviewUrl(reader.result);
      };
      reader.readAsDataURL(file);
    },
  });

  const renderAdditionalFields = () => {
    switch (partType) {
      case "cpu":
        return (
          <>
            <label htmlFor="socket">Socket:</label>
            <input
              type="text"
              id="socket"
              value={socket}
              onChange={(e) => setSocket(e.target.value)}
            />

            <label htmlFor="generation">Generation:</label>
            <input
              type="text"
              id="generation"
              value={generation}
              onChange={(e) => setGeneration(e.target.value)}
            />
            <label htmlFor="wattage">Wattage:</label>
            <input
              type="text"
              id="wattage"
              value={wattage}
              onChange={(e) => setWattage(e.target.value)}
            />
          </>
        );
      case "gpu":
        return (
          <>
            <label htmlFor="wattage">Wattage:</label>
            <input
              type="text"
              id="wattage"
              value={wattage}
              onChange={(e) => setWattage(e.target.value)}
            />
          </>
        );
      case "case":
        return (
          <>
            <label htmlFor="size">Size:</label>
            <input
              type="text"
              id="size"
              value={size}
              onChange={(e) => setSize(e.target.value)}
            />
          </>
        );
      case "memory":
        return (
          <>
            <label htmlFor="wattage">Wattage:</label>
            <input
              type="text"
              id="wattage"
              value={wattage}
              onChange={(e) => setWattage(e.target.value)}
            />
            <label htmlFor="ddrGen">DDR Generation:</label>
            <input
              type="text"
              id="ddrGen"
              value={ddrGen}
              onChange={(e) => setDdrGen(e.target.value)}
            />
          </>
        );
      case "motherboard":
        return (
          <>
            <label htmlFor="socket">Socket:</label>
            <input
              type="text"
              id="socket"
              value={socket}
              onChange={(e) => setSocket(e.target.value)}
            />
            <label htmlFor="cpuGenSupported">CPU Generation Supported:</label>
            <input
              type="text"
              id="cpuGenSupported"
              value={cpuGenSupported}
              onChange={(e) => setCpuGenSupported(e.target.value)}
            />
            <label htmlFor="size">Size:</label>
            <input
              type="text"
              id="size"
              value={size}
              onChange={(e) => setSize(e.target.value)}
            />
            <label htmlFor="ddrGenSupported">DDR Generation Supported:</label>
            <input
              type="text"
              id="ddrGenSupported"
              value={ddrGen}
              onChange={(e) => setDdrGen(e.target.value)}
            />
            <label htmlFor="wattage">Wattage:</label>
            <input
              type="text"
              id="wattage"
              value={wattage}
              onChange={(e) => setWattage(e.target.value)}
            />
          </>
        );
      case "psu":
        return (
          <>
            <label htmlFor="wattageDelivered">Wattage Delivered:</label>
            <input
              type="text"
              id="wattageDelivered"
              value={wattageDelivered}
              onChange={(e) => setWattageDelivered(e.target.value)}
            />
          </>
        );
      case "storage":
        return (
          <>
            <label htmlFor="wattage">Wattage:</label>
            <input
              type="text"
              id="wattage"
              value={wattage}
              onChange={(e) => setWattage(e.target.value)}
            />
          </>
        );
      default:
        return null;
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      // Prepare form data
      const formData = new FormData();
      formData.append("image", image);
      formData.append("partType", partType);
      formData.append("partName", partName);
      formData.append("price", price);
      formData.append("contents", contents);
      formData.append("stock", stock);
      formData.append("wattage", wattage);
      formData.append("socket", socket);
      formData.append("generation", generation);
      formData.append("size", size);
      formData.append("ddrGen", ddrGen);
      formData.append("cpuGenSupported", cpuGenSupported);
      formData.append("wattageDelivered", wattageDelivered);

      // Make API call to add part to the corresponding table
      const response = await axios.post(
        "http://localhost:8800/add-part",
        formData,
        {
          headers: {
            "Content-Type": "multipart/form-data",
          },
        }
      );
      console.log("Part added:", response.data);

      // Reset form fields after successful submission
      setPartName("");
      setPrice("");
      setContents("");
      setStock("");
      setWattage("");
      setSocket("");
      setGeneration("");
      setSize("");
      setDdrGen("");
      setCpuGenSupported("");
      setWattageDelivered("");
      setImage(null);
      setPreviewUrl(null);
    } catch (error) {
      console.error("Error adding part:", error);
    }
  };

  return (
    <div>
      <h2>Add Part</h2>
      <form onSubmit={handleSubmit}>
        <label htmlFor="partType">Select Part Type:</label>
        <select
          id="partType"
          onChange={(e) => setPartType(e.target.value)}
          value={partType}
        >
          <option value="">Select...</option>
          <option value="cpu">CPU</option>
          <option value="gpu">GPU</option>
          <option value="case">Case</option>
          <option value="memory">Memory</option>
          <option value="motherboard">Motherboard</option>
          <option value="psu">PSU</option>
          <option value="storage">Storage</option>
        </select>

        {/* Common input fields */}
        <label htmlFor="partName">Part Name:</label>
        <input
          type="text"
          id="partName"
          value={partName}
          onChange={(e) => setPartName(e.target.value)}
        />

        <label htmlFor="price">Price:</label>
        <input
          type="text"
          id="price"
          value={price}
          onChange={(e) => setPrice(e.target.value)}
        />

        <label htmlFor="contents">Contents:</label>
        <input
          type="text"
          id="contents"
          value={contents}
          onChange={(e) => setContents(e.target.value)}
        />

        <label htmlFor="stock">Stock:</label>
        <input
          type="text"
          id="stock"
          value={stock}
          onChange={(e) => setStock(e.target.value)}
        />
        {/* Render additional input fields based on selected part type */}
        {renderAdditionalFields()}
        {/* Dropzone for uploading image */}
        <div
          {...getRootProps()}
          style={{
            border: "2px dashed #ccc",
            padding: "20px",
            marginTop: "20px",
          }}
        >
          <input {...getInputProps()} />
          {isDragActive ? (
            <p>Drop the image here ...</p>
          ) : (
            <p>Drag 'n' drop an image here, or click to select an image</p>
          )}
          {previewUrl && (
            <img
              src={previewUrl}
              alt="Preview"
              style={{ marginTop: "20px", maxWidth: "100%", height: "auto" }}
            />
          )}
        </div>

        <button type="submit">Submit</button>
      </form>
      <ImageUploader></ImageUploader>
    </div>
  );
}

export default AddPart;
