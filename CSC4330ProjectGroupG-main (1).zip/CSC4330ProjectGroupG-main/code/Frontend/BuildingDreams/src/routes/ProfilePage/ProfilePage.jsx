import React from "react";
import "./ProfilePage.css";
import Logo from "./Logo.png";
import { Link } from "react-router-dom";

const GridItem = ({ children }) => (
  <div className="rectangle">{children}</div>
);

const ProfilePage = () => {
  return (
    <div className="background-gradient">
      <nav className="navigation">
        <Link className="custom-link" to="/PartSelector">
          <div className="backbutton">{'<<'} Back</div>
        </Link>
      </nav>
      <header>
        <img src={Logo} alt="Company Logo" className="logoimage" />
        <h1>Profile</h1>
      </header>
      <main className="grid-container">
        {["Saved Builds", "Orders", "Gift Cards", "Payment Info", "Login/Security", "Help Center", "Address", "Privacy", "Contact Us"].map((item) => (
          <GridItem key={item}>{item}</GridItem>
        ))}
      </main>
    </div>
  );
};

export default ProfilePage;
