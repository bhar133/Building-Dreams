import React from 'react'
import chatbubbles from "../Chatbox/chatbubbles.png"
import Chatbox from '../Chatbox/Chatbox'

const HomeSignedInPage = () => {
  
  return (
    <div>
      <Chatbox />
    </div>
  )
}

export default HomeSignedInPage
