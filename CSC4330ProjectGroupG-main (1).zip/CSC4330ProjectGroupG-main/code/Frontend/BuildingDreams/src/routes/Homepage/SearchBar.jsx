import React from "react";
import "./SearchBar.css";

function SearchBar({ placeholder }) {
  return (
    <form>
      <div className="search">
        <span className="search-icon material-symbols-outlined">search</span>
        <input
          className="search-input"
          type="search"
          placeholder={placeholder}
        />
      </div>
    </form>
  );
}

export default SearchBar;
