import React from "react";

const TransparentBox = ({ title, color }) => {
  return (
    <div className={`box ${color}`}>
      <div className="content">
        <span className={`title ${color}`}>{title}</span>
        <div className={`plus ${color}`}>+</div>
      </div>
    </div>
  );
};

export default TransparentBox;
