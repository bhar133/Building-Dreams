const BlueRoundedBox = () => {
  const style = {
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    width: "200px", // Adjust the width as needed
    height: "50px", // Adjust the height as needed
    backgroundColor: "blue",
    color: "black",
    borderRadius: "25px", // This gives the box rounded corners
    fontSize: "16px", // Adjust font size as needed
    fontWeight: "bold",
    cursor: "pointer", // Change the cursor to indicate the box is clickable
    userSelect: "none", // Prevent text selection
  };

  return <div style={style}>Login / Sign Up</div>;
};

export default BlueRoundedBox;
