import TransparentBox from "./TransparentBox";
import SearchBar from "./SearchBar";
import "./Homepage.css";
import logo from "./Logo.png";
import cart from "./Cart.png";
import { Link, useNavigate } from "react-router-dom";
import Chatbox from "../Chatbox/Chatbox";
import axios from "axios";

export default function Root() {

  const navigate = useNavigate()

  const handleClickSignUp = async e => {
    e.preventDefault()
    try{
      navigate("/Signup")
    }catch(err){
      console.log(err)
    }
  }


  return (
    <>
      <header className="HP-header">
        <nav className="HP-nav">
          <div className="HP-nav__data">
            <div className="HP-nav__logo">
              <img src={logo} alt="Your Image" />
            </div>
            <div className="HP-spacebar">
              <SearchBar placeholder="Search..." />
            </div>
            <div className="nav-button">
              <Link to="/ViewBuild">
                <img
                  src={cart}
                  alt="Your Image"
                  className="cartimage"
                  style={{ margin: "auto" }}
                />
              </Link>
              <Link className="custom-link" to="/SignIn">
                <p className="HP-p">Login</p>
              </Link>
              <button className="btn" onClick={handleClickSignUp}>Sign Up</button>
            </div>
          </div>
        </nav>
      </header>
      <div className="main-container">
        <div className="text">
          <p>
            Easy Way to build a PC specifically designed for
            <br />
            your components needs
          </p>
        </div>
        <div className="container-boxes">
          <Link className="custom-link" to="/PartSelector">
            <TransparentBox title="From Scratch" color="white" />
          </Link>
          <div className="marginSpace">
            <Link className="custom-link" to="/PartSelector">
              <TransparentBox title="Gaming PC" color="pink" />
            </Link>
            <Link className="custom-link" to="/PartSelector">
              <TransparentBox title="School PC" color="blue" />
            </Link>
          </div>
          <div className="marginSpace">
            <Link className="custom-link" to="/PartSelector">
              <TransparentBox title="Work PC" color="maroon" />
            </Link>
          </div>
        </div>

        <div>
          <Chatbox />
        </div>
      </div>
    </>
  );
}
