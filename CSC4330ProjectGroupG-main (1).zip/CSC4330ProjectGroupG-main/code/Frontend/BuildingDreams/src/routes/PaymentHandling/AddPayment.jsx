import React from "react";
import "./SelectPayment.css";
import "./PaymentInput.css"
//import axios from "axios";

const AddPayment = () => {
  return (
    <div className="background-gradient">
      <h1>Add Payment Method</h1>
      <div className="cardInfoContainer">
        <h2>Enter Card Information</h2>
        <form>
          <div className="inputGroup">
            <label htmlFor="cardNumber">Card Number</label>
            <input
              type="text"
              id="cardNumber"
              placeholder="1234 5678 9012 3456"
            />
          </div>
          <div className="inputGroup">
            <label htmlFor="expDate">Expiration Date</label>
            <input type="text" id="expDate" placeholder="MM/YY" />
          </div>
          <div className="inputGroup">
            <label htmlFor="cvv">CVV</label>
            <input type="text" id="cvv" placeholder="123" />
          </div>
          <button type="submit">Submit</button>
        </form>
      </div>
    </div>
  );
};

export default AddPayment;
