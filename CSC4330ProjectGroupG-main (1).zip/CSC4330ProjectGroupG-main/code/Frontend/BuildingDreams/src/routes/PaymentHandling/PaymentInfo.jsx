import React from "react";
import { Link } from "react-router-dom";
import Logo from "./Logo.png";
import "./SelectPayment.css"
//import axios from "axios";

const SelectPayment = () => {
  return (
    <>
      <div className="background-gradient">
        <Link className="custom-link" to="/PartSelector">
          <div className="backbutton">
            {"\u003c"}
            {"\u003c"}Back
          </div>
        </Link>
        <div>
          <img src={Logo} alt="Your Image" className="logoimage"></img>
        </div>
        <div>
          <h1>Payment Info</h1>
        </div>
        <div className="container">
          <div className="box">Payment Method 1</div>
          <div className="box">Payment Method 2</div>
          <div className="box">Payment Method 3</div>
        </div>
        <div>
          <h2>Add New Payment Method +</h2>
        </div>
      </div>
    </>
  );
};

export default SelectPayment;
