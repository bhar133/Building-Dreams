import React from "react";
import { Link } from "react-router-dom";
import Logo from "./Logo.png";
import "./SelectPayment.css";
//import axios from "axios";

const SelectPayment = () => {
  return (
    <>
      <div className="background-gradient">
        <Link className="custom-link" to="/PartSelector">
          <div className="backbutton">
            {"\u003c"}
            {"\u003c"}Back
          </div>
        </Link>
        <div>
          <img src={Logo} alt="Your Image" className="logoimage"></img>
        </div>
        <div>
          <h1>Select Payment Method</h1>
        </div>
        <div className="container">
          <div className="box">Payment Method 1</div>
          <div className="box">Payment Method 2</div>
          <div className="box">Payment Method 3</div>
        </div>
        <div>
          <button className="confirmButton">Confirm Purchase</button>
        </div>
      </div>
    </>
  );
};

export default SelectPayment;
