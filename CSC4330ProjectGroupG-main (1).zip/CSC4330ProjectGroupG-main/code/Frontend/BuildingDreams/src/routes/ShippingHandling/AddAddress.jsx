import React from 'react'
//import axios from "axios";

const AddAddress = () => {
  return (
    <div>
      <h1>Add Address</h1>
    </div>
  )
}

export default AddAddress
