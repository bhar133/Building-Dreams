import React, { useState } from 'react';
import './PickSavedBuild.css'; // Import the accompanying stylesheet

const builds = [
  { id: 1, name: 'Gaming Rig' },
  { id: 2, name: 'Workstation Build' },
  { id: 3, name: 'Budget PC' },
  // Add more builds as needed
];

const PickSavedBuild = () => {
  const [selectedBuild, setSelectedBuild] = useState();

  return (
    <div className="builds-container">
      <h1 className="title">Saved Builds</h1>
      <ul className="builds-list">
        {builds.map((build) => (
          <li 
            key={build.id} 
            className={`build-item ${selectedBuild === build.id ? 'selected' : ''}`}
            onClick={() => setSelectedBuild(build.id)}
          >
            {build.name}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default PickSavedBuild;
