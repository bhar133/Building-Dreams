import React from 'react'
import "./ProductDetails.css"; // Import your stylesheet

const AddMore = () => {
    return (
        <>
          <div className="containerproducts">
            <div className="white-box"></div>
            <div className="part">
              <div>Add More</div>
              
            </div>
            <div className="part">
                <div><br></br></div>
            </div>
            <div className="part">
                <div><br></br></div>
            </div>
          </div>
        </>
      );
}

export default AddMore
