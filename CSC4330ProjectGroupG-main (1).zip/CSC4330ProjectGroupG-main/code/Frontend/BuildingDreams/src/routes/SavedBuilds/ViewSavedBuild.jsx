import React, { useState, useEffect } from "react";
import "./ViewSavedBuild.css";
import { Button } from "bootstrap";
//import { useHistory } from "react-router-dom";
import logo from "./Logo.png";
import cart from "./Cart.png";
import { Link } from "react-router-dom";
import { useNavigate } from "react-router-dom";
import Chatbox from "../Chatbox/Chatbox";

const ViewSavedBuild = () => {
  const navigate = useNavigate();
  const [savedBuilds, setSavedBuilds] = useState(() => {
    const savedBuilds = localStorage.getItem("savedBuilds");
    return savedBuilds ? JSON.parse(savedBuilds) : [];
  });

  const isBuildCompatible = (build) => {
    console.log(build);
    // Perform compatibility check here
    const cpu = Object.values(build).find((part) => part.partType === "cpus");
    const motherboard = Object.values(build).find(
      (part) => part.partType === "motherboards"
    );
    const memory = Object.values(build).find(
      (part) => part.partType === "memory"
    );
    const gpu = Object.values(build).find((part) => part.partType === "gpus");
    const storage = Object.values(build).find(
      (part) => part.partType === "storage"
    );
    const cases = Object.values(build).find(
      (part) => part.partType === "cases"
    );
    const psu = Object.values(build).find((part) => part.partType === "psus");
    if (!cpu || !motherboard || !memory || !psu || !gpu || !storage || !cases) {
      return { compatible: false, reason: "Incomplete build" }; // Build is incomplete
    }
    console.log(cpu.socket);
    // Check CPU and motherboard sockets
    if (cpu.socket !== motherboard.socket) {
      return {
        compatible: false,
        reason: "CPU socket does not match motherboard socket",
      };
    }

    if (cases.size !== motherboard.size) {
      return {
        compatible: false,
        reason: "Motherboard size does not match case size",
      };
    }

    // Check DDR generation of motherboard and RAM
    if (motherboard.ddrGen !== memory.ddrGen) {
      return {
        compatible: false,
        reason: "DDR generation of motherboard does not match RAM",
      };
    }

    // Add more compatibility checks as needed

    return { compatible: true, reason: "Compatible" }; // Build is compatible
  };

  const handleAddToCart = (part) => {
    // Add the selected part to the cart in local storage
    const cart = JSON.parse(localStorage.getItem("cart")) || [];
    cart.push(part);
    localStorage.setItem("cart", JSON.stringify(cart));

    // Update the UI or trigger any other action as needed
  };
  const formatBuild = (build) => {
    console.log(typeof build);
    const formattedBuild = [];

    // Iterate over the properties of the build object
    for (const key in build) {
      // Exclude non-part properties like the build name
      if (key !== "name") {
        // Push the part object into the formatted array
        formattedBuild.push(build[key]);
      }
    }
    console.log(formattedBuild);
    return formattedBuild;
  };
  const handleEditBuild = (build, index) => {
    // Save the selected build in local storage
    const formattedBuild = formatBuild(build);
    localStorage.setItem("build", JSON.stringify(formattedBuild));
    deleteSavedBuild(index);
    // Redirect to the part selector page
    //history.go;
    navigate("/partselector");
  };
  const deleteSavedBuild = (buildIndex) => {
    // Copy the current array of saved builds
    const updatedSavedBuilds = [...savedBuilds];

    // Remove the build at the specified index
    updatedSavedBuilds.splice(buildIndex, 1);

    // Update the local storage with the updated array of saved builds
    localStorage.setItem("savedBuilds", JSON.stringify(updatedSavedBuilds));

    // Update the state to reflect the deletion
    setSavedBuilds(updatedSavedBuilds);
  };
  return (
    <>
      <header className="HP-header">
        <nav className="HP-nav">
          <div className="HP-nav__data">
            <div className="HP-nav__logo">
              <img src={logo} alt="Your Image" />
            </div>
            <div className="HP-spacebar"></div>
            <div className="nav-button">
              <Link to="/Checkout">
                <img
                  src={cart}
                  alt="Your Image"
                  className="cartimage"
                  style={{ margin: "auto" }}
                />
              </Link>
              <Link className="custom-link" to="/PartSelector">
                <button className="btn">Part Selector</button>
              </Link>
            </div>
          </div>
        </nav>
      </header>
      <div className="builds-grid">
        <h1>Saved Builds</h1>
        <div className="grid-container">
          {savedBuilds.map((build, index) => (
            <div key={index} className="build-card">
              <h1 className="build-header">{build.name}</h1>
              {Object.values(build)
                .filter((part) => typeof part === "object")
                .map((part, partIndex) => (
                  <div key={partIndex} className="part-container">
                    <div className="text">
                      <div>
                        {part.partName} - ${part.price}
                      </div>
                    </div>
                    <button onClick={() => handleAddToCart(part)}>
                      Add to Cart
                    </button>
                  </div>
                ))}
              <div
                className={`compatibility-indicator ${
                  isBuildCompatible(build).compatible
                    ? "compatible"
                    : "incompatible"
                }`}
              >
                {isBuildCompatible(build).reason}
              </div>
              <button onClick={() => handleEditBuild(build, index)}>
                Edit Build
              </button>
              <button onClick={() => deleteSavedBuild(index)}>Delete</button>
            </div>
          ))}
        </div>
        <Chatbox></Chatbox>
      </div>
    </>
  );
};

export default ViewSavedBuild;
