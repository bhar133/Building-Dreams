import React from "react";
import "./ProductDetails.css"; // Import your stylesheet

function ProductDetails() {
  return (
    <>
      <div className="containerproducts">
        <div className="white-box"></div>
        <div className="part">
          <div>Part</div>
          <div>Price</div>
        </div>
        <div className="part">
            <div>Brand</div>
        </div>
        <div className="part">
            <div>Description</div>
        </div>
      </div>
    </>
  );
}

export default ProductDetails;
