import React, { useState, useEffect } from "react";
import "./CheckOutConfirmation.css";
import { Link } from "react-router-dom";

const CheckOutConfirmation = ({}) => {
  const [fireworks, setFireworks] = useState(false);

  useEffect(() => {
    // Trigger fireworks after 1 second
    const fireworksTimer = setTimeout(() => {
      setFireworks(true);
    }, 1000);

    // Clear the timer
    return () => clearTimeout(fireworksTimer);
  }, []);

  return (
    <div className="checkout-confirmation">
      {fireworks && (
        <div className="fireworks-container">
          {[...Array(20)].map((_, index) => (
            <div
              key={index}
              className="firework"
              style={{
                backgroundColor: randomColor(),
                top: `${getRandomNumber(5, 95)}%`,
                left: `${getRandomNumber(5, 95)}%`,
                animationDuration: `${getRandomNumber(800, 1200)}ms`,
              }}
            ></div>
          ))}
        </div>
      )}
      <h1 className="order-sent-message">Your order has been sent!</h1>
      <Link to="/" className="continue-shopping-link">
        Continue Shopping
      </Link>
    </div>
  );
};

export default CheckOutConfirmation;

function getRandomNumber(min, max) {
  return Math.floor(Math.random() * (max - min + 1) + min);
}

function randomColor() {
  return `hsl(${getRandomNumber(0, 360)}, ${getRandomNumber(50, 100)}%, ${getRandomNumber(50, 70)}%)`;
}
