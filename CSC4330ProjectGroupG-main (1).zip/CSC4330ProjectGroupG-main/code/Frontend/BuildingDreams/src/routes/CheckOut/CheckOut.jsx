import React, { useEffect, activeTab, useState } from "react";
import "./CheckOut.css";
import { Link } from "react-router-dom";

const CheckOut = ({}) => {
    const [cart, setCart] = useState(() => {
        const savedCart = localStorage.getItem("cart");
        return savedCart ? JSON.parse(savedCart) : [];
      });
      
    const [totalPrice, setTotalPrice] = useState(
        cart.reduce((acc, item) => acc + item.price, 0)
    );

    const removeFromCart = (index) => {
        const updatedCart = [...cart];
        updatedCart.splice(index, 1);
        const updatedTotalPrice = updatedCart.reduce((acc, item) => acc + item.price, 0);
        setTotalPrice(updatedTotalPrice);
        setCart(updatedCart);
        localStorage.setItem("cart", JSON.stringify(updatedCart));
      };

      return (
        <div className="checkout-page">
          <Link to="./../PartSelector">
            <button className="return-button">Return To Part Selection</button>
          </Link>
          <hr className="line" />
          <h1>Checkout</h1>
          <hr className="line" />
          <ul className="checkout-cart-items">
            {cart.map((item, index) => (
              <li key={index} className="checkout-cart-item">
                <img src={item.imageUrl} alt={item.partName} className="cart-item-image" />
                <span>
                  {item.partName} - ${item.price}
                </span>
                <button className="remove-button" onClick={() => removeFromCart(index)}>Remove Item</button>
                <hr className="item-line" />
              </li>
            ))}
          </ul>
          <p className="checkout-total-price">Total Price: ${totalPrice.toFixed(2)}</p>
          <Link to="/CheckOutPayment">
            <button className="payment-button">Proceed to Payment</button>
          </Link>
        </div>
      );
};

export default CheckOut;
