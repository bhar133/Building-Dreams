import React from "react";
import logo from "./Logo.png";
import "./SignupPage.css"; // Import CSS file for styling
import UsernameBar from "./UsernameBar";
import PasswordBar from "./PasswordBar";
import ConfirmPasswordBar from "./ConfirmPasswordBar";
import PhoneNumberBar from "./PhoneNumberBar";
import TransparentBox from "./TransparentBox";
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Link } from "react-router-dom";
import axios from "axios";

const SignupPage = () => {
  const [inputs, setInputs] = useState({
    username: "",
    password: "",
    number: "",
  });
  const [err, setErr] = useState(null);

  const navigate = useNavigate();

  const handleChange = (e) => {
    setInputs((prev) => ({ ...prev, [e.target.name]: e.target.value }));
  };
  console.log(inputs);

  const handleClick = async (e) => {
    e.preventDefault();
    try {
      await axios.post("http://localhost:8800/backend/auth/register", inputs);
      navigate("/");
    } catch (err) {
      setErr(err.response.data);
    }
  };

  console.log(err);

  return (
    <div className="signup">
      <h1>Sign Up</h1>
      <input
        type="text"
        placeholder="Username"
        name="username"
        onChange={handleChange}
      />
      <input
        type="password"
        placeholder="Password"
        name="password"
        onChange={handleChange}
      />
      <input
        type="text"
        placeholder="###-###-####"
        name="number"
        onChange={handleChange}
      />

      <button onClick={handleClick}>Sign up</button>
      {err && <p>{err}</p>}
    </div>
    // <div className="signin-container">
    //   <img src={logo} alt="Your Image" className="logo" />
    //   <h1 className="signin-heading">Enter Sign Up Info:</h1>
    //   <div style={{maxWidth: "800px", margin: "10px", width: '40%' }}>
    //       <UsernameBar />
    //   </div>
    //   <div style={{maxWidth: "800px", margin: "10px", width: '40%' }}>
    //       <PasswordBar />
    //   </div>
    //   <div style={{maxWidth: "800px", margin: "10px", width: '40%' }}>
    //       <ConfirmPasswordBar />
    //   </div>
    //   <div style={{maxWidth: "800px", margin: "10px", width: '40%' }}>
    //       <PhoneNumberBar />
    //   </div>
    //   <div className='link-container'>
    //     <a href="HomeSignedInPage">
    //       <TransparentBox title="Sign Up" color="white" />
    //     </a>
    //   </div>
    // </div>
  );
};

export default SignupPage;
