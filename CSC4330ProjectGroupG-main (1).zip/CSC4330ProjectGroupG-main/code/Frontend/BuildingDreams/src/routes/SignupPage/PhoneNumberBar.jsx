import React, { useState } from 'react';

const UsernameBar = () => {
  const [value, setValue] = useState('');

  const style = {
    padding: '10px 15px',
    fontSize: '16px',
    border: '2px solid #ccc',
    borderRadius: '20px', // Gives the search bar rounded corners
    outline: 'none', // Removes the outline to keep the design clean
    width: 'calc(100% - 32px)', // Adjusts width to fit its container, accounting for padding
    boxSizing: 'border-box', // Ensures padding doesn't add to the total width and height
  };

  const handleInputChange = (e) => {
    const input = e.target.value.replace(/\D/g, ''); // Remove non-digit characters
    let formattedInput = '';

    // Slice and format the input to match the (###)-###-#### format
    if (input.length > 0) {
      formattedInput += `(${input.slice(0, 3)}`;
    }
    if (input.length >= 3) {
      formattedInput += `)-${input.slice(3, 6)}`;
    }
    if (input.length > 6) {
      formattedInput += `-${input.slice(6, 10)}`;
    }

    setValue(formattedInput);
  };

  return (
    <input
      type="text"
      placeholder="(###)-###-####"
      style={style}
      value={value}
      onChange={handleInputChange}
      maxLength={14} // Account for the formatting characters
    />
  );
};

export default UsernameBar;
