import React from 'react';

const TransparentBox = ({ title, color }) => {
  return (
    <div className={`box ${color}`}>
      <div className="content">
        <span className="title">{title}</span>
      </div>
    </div>
  );
}

export default TransparentBox;