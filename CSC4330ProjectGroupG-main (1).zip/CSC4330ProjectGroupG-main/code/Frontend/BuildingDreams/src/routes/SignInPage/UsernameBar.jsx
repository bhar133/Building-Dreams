const UsernameBar = () => {
    const style = {
      padding: '10px 15px',
      fontSize: '16px',
      border: '2px solid #ccc',
      borderRadius: '20px', // Gives the search bar rounded corners
      outline: 'none', // Removes the outline to keep the design clean
      width: 'calc(100% - 32px)', // Adjusts width to fit its container, accounting for padding
      boxSizing: 'border-box', // Ensures padding doesn't add to the total width and height
    };
  
    return (
      <input
        type="text"
        placeholder="Username..."
        style={style}
      />
    );
  };
  
  export default UsernameBar;