import React from "react";
import logo from "./Logo.png";
import "./SigninPage.css"; // Import CSS file for styling
import { Link } from "react-router-dom";
import { useContext, useState } from "react";
import { AuthContext } from "../../authContext";
import { useNavigate } from "react-router-dom";

const login = () => {
  const [inputs, setInputs] = useState({
    username: "",
    password: "",
  });
  const [err, setErr] = useState(null);

  const navigate = useNavigate();

  const handleChange = (e) => {
    setInputs((prev) => ({ ...prev, [e.target.name]: e.target.value }));
  };
  console.log(inputs);
  const { login } = useContext(AuthContext);

  const handleLogin = async (e) => {
    e.preventDefault();
    try {
      await login(inputs);
      navigate("/");
    } catch (err) {
      setErr(err.response.data);
    }
  };

  // const SigninPage = () => {
  //   const navigate = useNavigate();
  //     const handleClick = async e => {
  //       e.preventDefault()
  //       try{
  //         navigate("/")
  //       }catch(err){
  //         console.log(err)
  //       }
  //     }

  const handleClickSignUp = async (e) => {
    e.preventDefault();
    try {
      navigate("/Signup");
    } catch (err) {
      console.log(err);
    }
  };
  return (
    <>

      <div className="SI-PAGE">
        <div className="SI-CONTAINER">
          <Link className="custom-link" to="/">
            <div className="backbutton">
              {"\u003c"}
              {"\u003c"}Back
            </div>
          </Link>
          <img src={logo} alt="Your Image" id="SP-IMG" />
          <h1 className="SP-SIGN_HEADING">Enter Sign In Info:</h1>
          <form className="SP-FORM">

            <input
              className="SP-LOGIN"
              type="text"
              placeholder="Username"
              name="username"
              onChange={handleChange}
            />
            <input
              className="SP-LOGIN"
              type="password"
              placeholder="Password"
              name="password"
              onChange={handleChange}
            />
            {err && err}
          </form>
          <form className="SP-LOGIN_FORM">
            <button
              className="SP-LOGIN_BUTTONS"
              id="SP-SIGN_IN_BTN"
              onClick={handleLogin}
            >
              Login
            </button>
            <button
              className="SP-LOGIN_BUTTONS"
              id="SP-SIGN_UP_BTN"
              onClick={handleClickSignUp}
            >
              Sign Up
            </button>
          </form>
        </div>
      </div>
    </>
  );
};

export default login;
