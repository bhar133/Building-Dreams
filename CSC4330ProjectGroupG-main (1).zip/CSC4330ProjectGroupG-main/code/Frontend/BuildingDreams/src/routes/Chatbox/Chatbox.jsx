import React, { useState } from 'react';
import './Chatbox.css';
import OpenAI from "openai";

function Chatbox() {
  const [isChatboxVisible, setChatboxVisibility] = useState(false);
  const [inputValue, setInputValue] = useState('');
  const [response, setResponse] = useState('');

  const openai = new OpenAI({ 
    apiKey: 'sk-proj-7ciEmFdibbzNwSZlwrEqT3BlbkFJ6hhzEiHok1QsiidsOUeu',
    dangerouslyAllowBrowser: true
  });

  const handleChatSubmit = async () => {
    try {
      const completion = await openai.chat.completions.create({
        messages: [{ role: "user", content: inputValue }],
        model: "gpt-3.5-turbo",
      });
      console.log(completion.choices[0]);
      setResponse(completion.choices[0].message.content); // Display the response
    } catch (error) {
      console.error("Failed to fetch completion:", error);
    }
  };

  const toggleChatbox = () => setChatboxVisibility(!isChatboxVisible);

  const handleInputChange = (event) => setInputValue(event.target.value);

  return (
    <div className="chatbox-container">
      <div className={`circle ${isChatboxVisible ? 'hidden' : ''}`} onClick={toggleChatbox}>
        Chat
      </div>
      {isChatboxVisible && (
        <div className="chatbox">
          <span className="close-button" onClick={toggleChatbox}>X</span>
          <textarea
            className="text-box"
            value={inputValue}
            onChange={handleInputChange}
            autoFocus
            placeholder="Type here..."
          />
          <button onClick={handleChatSubmit}>Send</button>
          {response && <div className="response">{response}</div>}
        </div>
      )}
    </div>
  );
}

export default Chatbox;
