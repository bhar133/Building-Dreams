import * as React from "react";
import * as ReactDOM from "react-dom/client";
import { createBrowserRouter, RouterProvider } from "react-router-dom";
import "./index.css";

import HomePage from "./routes/Homepage/Homepage";
import SigninPage from "./routes/SignInPage/SigninPage";
import PartSelector from "./routes/PartSelectors/PartSelector";
import AddPayment from "./routes/PaymentHandling/AddPayment";
import SelectPayment from "./routes/PaymentHandling/SelectPayment";
import ViewSavedBuilds from "./routes/SavedBuilds/ViewSavedBuild";
import PickSavedBuilds from "./routes/SavedBuilds/PickSavedBuild";
import AddAddress from "./routes/ShippingHandling/AddAddress";
import PickAddress from "./routes/PaymentHandling/ShippingInfo";
import Confirmation from "./routes/PaymentHandling/ConfirmInfo";
import ProfilePage from "./routes/ProfilePage/ProfilePage";
import SignUpPage from "./routes/SignupPage/SignupPage";
import HomeSignedInPage from "./routes/Homepage/HomeSignedInPage";
import ShippingInfo from "./routes/PaymentHandling/ShippingInfo";
import ShippingAddresses from "./routes/PaymentHandling/ShippingAddress";
import AdminPage from "./routes/AdminPage/adminpage";
import PaymentInfo from "./routes/PaymentHandling/PaymentInfo";
import CheckOut from "./routes/CheckOut/CheckOut";
import CheckOutPayment from "./routes/CheckOut/CheckOutPayment";
import CheckOutConfirmation from "./routes/CheckOut/CheckOutConfirmation";


import { AuthContext, AuthContextProvider } from "./authContext";
import { useContext } from "react";

function App() {
  const { currentUser } = useContext(AuthContext);

  const ProtectedRoute = ({ children }) => {
    if (!currentUser) {
      return <Navigate to="/SigninPage" />;
    }
    return children;
  };

  const router = createBrowserRouter([
    {
      path: "/",
      element: <HomePage />,
    },
    {
      path: "/PartSelector",
      element: <PartSelector />,
    },
    {
      path: "/ShippingAddresses",
      element: <ShippingAddresses />,
    },
    {
      path: "/PaymentInfo",
      element: <PaymentInfo />,
    },
    {
      path: "/SignIn",
      element: <SigninPage />,
    },
    {
      path: "/SignUp",
      element: <SignUpPage />,
    },
    {
      path: "/Profile",
      element: <ProfilePage />,
    },
    {
      path: "/Home",
      element: <HomePage />,
    },
    {
      path: "/HomeIn",
      element: <HomeSignedInPage />,
    },
    {
      path: "/ConfirmInfo",
      element: <Confirmation />,
    },
    {
      path: "/AddPayment",
      element: <AddPayment />,
    },
    {
      path: "/SelectPayment",
      element: <SelectPayment />,
    },
    {
      path: "/PickBuild",
      element: <PickSavedBuilds />,
    },
    {
      path: "/ViewBuild",
      element: <ViewSavedBuilds />,
    },
    {
      path: "/AddAddress",
      element: <AddAddress />,
    },
    {
      path: "/ShippingInfo",
      element: <ShippingInfo />,
    },
    {
      path: "/PickAddress",
      element: <PickAddress />,
    },
    {
      path: "/AdminPage",
      element: <AdminPage />,
    },
    {
      path: "/CheckOut",
      element: <CheckOut />
    },
    {
      path: "/CheckOutPayment",
      element: <CheckOutPayment />
    },
    {
      path: "/CheckOutConfirmation",
      element: <CheckOutConfirmation />
    },
  ]);

  return (
    <div>
      <RouterProvider router={router} />
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <AuthContextProvider>
      <App />
    </AuthContextProvider>
  </React.StrictMode>
);

export default App;
