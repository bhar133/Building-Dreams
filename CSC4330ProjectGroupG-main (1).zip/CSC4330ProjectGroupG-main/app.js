import express from 'express'
import cors from 'cors'
import cookieParser from 'cookie-parser'
import authRoutes from "./auth.js";
import bodyParser from "body-parser";
const app = express()
import {db} from "./database.js";
import dotenv from 'dotenv'
import multer from 'multer';
const router = express.Router();
import path from 'path';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';
dotenv.config()

app.use((req, res, next) => {
  res.header("Access-Control-Allow-Credentials", true);
  next();
});
app.use(express.json());
app.use(
  cors({
    origin: "http://localhost:5173",
  })
);

app.use(cookieParser());
app.listen(8800, () => {
  console.log("Server is running on port 8800")
})


db.connect(err => {
if (err) {
    return console.error('error connecting: ' + err.stack);
}
console.log('connected as id ' + db.threadId);
});

// Multer configuration
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, "uploads/"); // Specify the folder where you want to save the files
  },
  filename: function (req, file, cb) {
    cb(null, Date.now() + path.extname(file.originalname)); // Use a unique filename to avoid conflicts
  },
});

const upload = multer({ storage });
// Middleware to parse JSON bodies
app.use(bodyParser.json());

// Define the POST endpoint to add an image path
app.post('/upload', upload.single('image'), (req, res) => {
  const id = req.body.id;
  const table = req.body.table;
  const imageName = req.file.filename;
  console.log(req);
  console.log(imageName);
  const filePath = req.file.path; // The path to the file on the server

  //Example: Update your database here
  db.query(`UPDATE ${table} SET imagePath = '${imageName}' WHERE id = ${id}`, function(err, result) {
     if (err) throw err;
     console.log("1 record updated");
   });

  res.send('File uploaded and path updated successfully!');
});
// Upload image route
app.post("/upload-image", upload.single("image"), (req, res) => {
  if (!req.file) {
    //return res.status(400).json({ message: "No file uploaded" });
    console.log("your an idiot");
  }

  const imagePath = req.file.path;
  // Here you can perform any additional processing if needed, such as resizing the image or adding it to a database

  //res.status(200).json({ imagePath: imagePath });
});





//This function adds pc part to parts in the database
// Middleware to parse JSON bodies
app.use(bodyParser.json());




// Endpoint to add a part
app.post('/add-part', upload.single('image'), (req, res) => {
  const {
    partType,
    partName,
    price,
    contents,
    stock,
    wattage,
    socket,
    generation,
    size,
    ddrGen,
    cpuGenSupported,
    wattageDelivered
  } = req.body;
  //const imagePath = req.file.path; // Path to the uploaded image
  const imagePath = req.file ? req.file.path : null;
  console.log(imagePath);
  // Prepare SQL query based on part type
  let query;
  let values;
  switch (partType) {
    case 'cpu':
      values = [partName, price, contents, stock, wattage, socket, generation, imagePath || null];
      query = 'INSERT INTO cpus (part_name, price, contents, stock, wattage, socket, generation, imagePath) VALUES (?, ?, ?, ?, ?, ?, ?, ?)';
      //values = [partName, price, contents, stock, wattage, socket, generation, imagePath || null];
      break;
    case 'gpu':
      query = 'INSERT INTO gpus (part_name, price, contents, stock, wattage, imagePath) VALUES (?, ?, ?, ?, ?, ?)';
      values = [partName, price, contents, stock, wattage, imagePath || null];
      break;
    case 'case':
      query = 'INSERT INTO cases (part_name, price, contents, stock, size, image) VALUES (?, ?, ?, ?, ?, ?)';
      values = [partName, price, contents, stock, size, imagePath || null];
      break;
    case 'memory':
      query = 'INSERT INTO memory (part_name, price, contents, stock, wattage, ddr_gen, image) VALUES (?, ?, ?, ?, ?, ?, ?)';
      values = [partName, price, contents, stock, wattage, ddrGen, imagePath || null];
      break;
    case 'motherboard':
      query = 'INSERT INTO motherboards (part_name, price, contents, stock, wattage, socket, cpu_gen_supported, size, ddr_gen_supported, image) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)';
      values = [partName, price, contents, stock, wattage, socket, cpuGenSupported, size, ddrGen, imagePath || null];
      break;
    case 'psu':
      query = 'INSERT INTO psus (part_name, price, contents, stock, wattage_delivered, image) VALUES (?, ?, ?, ?, ?, ?)';
      values = [partName, price, contents, stock, wattageDelivered, imagePath || null];
      break;
    case 'storage':
      query = 'INSERT INTO storage (part_name, price, contents, stock, wattage, image) VALUES (?, ?, ?, ?, ?, ?)';
      values = [partName, price, contents, stock, wattage, imagePath || null];
      break;
    default:
      return res.status(400).json({ error: 'Invalid part type' });
  }
  ;

  // Execute the SQL query
  db.query(query, values, (error, results, fields) => {
    if (error) {
      console.error('Error adding part:', error);
      return res.status(500).json({ error: 'Failed to add part to database' });
    }
    res.status(201).json({ message: 'Part added successfully', partId: results.insertId });
  });
});

export default router;
app.get("/parts/:type", (req, res) => {
  const partType = req.params.type;
  const query = `SELECT * FROM ${partType}`; // Assuming table names match part types (e.g., 'cpus', 'motherboards', etc.)

  // Execute SQL query
  db.query(query, (err, results) => {
    if (err) {
      console.error("Error fetching parts:", err);
      res.status(500).json({ error: "Failed to fetch parts from database" });
    } else {
      
      res.json({ parts: results }); // Assuming results contain an array of parts
      
    }
  });
});
const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

app.use('/uploads', express.static(join(__dirname, 'uploads')));
app.use("/backend/auth", authRoutes);



