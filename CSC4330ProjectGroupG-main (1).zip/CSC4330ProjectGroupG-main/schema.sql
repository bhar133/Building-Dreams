drop DATABASE IF EXISTS PC_PARTS;
CREATE DATABASE pc_parts;
USE pc_parts;

DROP TABLE IF EXISTS cpus;
CREATE TABLE cpus (
    id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    part_name VARCHAR(255) DEFAULT NULL,
    price FLOAT(5, 2) DEFAULT NULL,
    contents VARCHAR(255) DEFAULT NULL,
    stock INT(4) DEFAULT NULL,
    wattage INT(3) DEFAULT NULL,
    socket VARCHAR(255) DEFAULT NULL,
    generation INT(5) DEFAULT NULL,
    imagePath VARCHAR(255) DEFAULT NULL
);
LOCK TABLES cpus WRITE;

INSERT INTO cpus (part_name, price, contents, stock, wattage, socket, generation, imagePath) VALUES 
('Intel Core i9-11900K',549.99,'CPU Only',100,125,'LGA 1200',11,'1713477744853.jpg'),
('AMD Ryzen 9 5950X',799.99,'CPU Only',75,105,'AM4',5,'1713477767196.jpg'),
('Intel Core i7-11700K',399.99,'CPU Only',150,125,'LGA 1200',11,'1713477961404.jpg'),
('AMD Ryzen 7 5800X',449.99,'CPU Only',100,105,'AM4',5,'1713478156066.jpg'),
('Intel Core i5-11600K',269.99,'CPU Only',200,125,'LGA 1200',11,'1713478196639.jpg'),
('AMD Ryzen 5 5600X',299.99,'CPU Only',150,65,'AM4',5,'1713478224290.jpg'),
('Intel Core i9-10900K',529.99,'CPU Only',50,125,'LGA 1200',10,'1713478246311.jpg'),
('AMD Ryzen 9 5900X',549.99,'CPU Only',100,105,'AM4',5,'1713478272283.jpg'),
('Intel Core i7-10700K',349.99,'CPU Only',100,125,'LGA 1200',10,'1713478309741.jpg'),
('AMD Ryzen 7 3800X',339.99,'CPU Only',75,105,'AM4',3,'1713478353053.jpg');

UNLOCK TABLES;

DROP TABLE IF EXISTS motherboards;
CREATE TABLE motherboards (
    id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    part_name VARCHAR(255) DEFAULT NULL,
    price FLOAT(5, 2) DEFAULT NULL,
    contents VARCHAR(255) DEFAULT NULL,
    stock INT(4) DEFAULT NULL,
    wattage INT(3) DEFAULT NULL ,
    socket VARCHAR(255) DEFAULT NULL,
    cpu_gen_supported INT(5) DEFAULT NULL,
    size VARCHAR(255) DEFAULT NULL,
    ddr_gen_supported INT(3) DEFAULT NULL,
    imagePath VARCHAR(255) DEFAULT NULL
);

LOCK TABLES motherboards WRITE;

INSERT INTO motherboards (part_name, price, contents, stock, wattage, socket, cpu_gen_supported, size, ddr_gen_supported, imagePath) VALUES 
('ASUS ROG Strix Z590-E Gaming',349.99,'Motherboard, User Manual, SATA cables, Wi-Fi antennas',100,150,'LGA 1200',10,'ATX',4,'1713479777977.jpg'),
('GIGABYTE B550 AORUS PRO',159.99,'Motherboard, User Manual, SATA cables',150,120,'AM4',5,'ATX',4,NULL),
('MSI MPG B450 Gaming Plus',109.99,'Motherboard, User Manual, SATA cables',200,95,'AM4',3,'ATX',4,NULL),
('ASRock B560 Steel Legend',139.99,'Motherboard, User Manual, SATA cables',100,100,'LGA 1200',11,'ATX',4,NULL),
('ASUS ROG Strix X570-E Gaming',329.99,'Motherboard, User Manual, SATA cables, Wi-Fi antennas',80,150,'AM4',3,'ATX',4,NULL),
('MSI MAG B550 TOMAHAWK',179.99,'Motherboard, User Manual, SATA cables',120,120,'AM4',5,'ATX',4,NULL),
('GIGABYTE Z490 AORUS Elite AC',199.99,'Motherboard, User Manual, SATA cables, Wi-Fi antennas',90,125,'LGA 1200',10,'ATX',4,NULL),
('ASRock X570 Phantom Gaming 4',149.99,'Motherboard, User Manual, SATA cables',110,150,'AM4',3,'ATX',4,NULL),
('MSI MAG B460M Mortar',114.99,'Motherboard, User Manual, SATA cables',140,95,'LGA 1200',10,'Micro-ATX',4,NULL),
('ASUS TUF Gaming B550-PLUS',159.99,'Motherboard, User Manual, SATA cables',130,120,'AM4',5,'ATX',4,NULL);

UNLOCK TABLES;

DROP TABLE IF EXISTS memory;
CREATE TABLE memory(
    id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    part_name VARCHAR(255) DEFAULT NULL,
    price FLOAT(5, 2) DEFAULT NULL,
    contents VARCHAR(255) DEFAULT NULL,
    stock INT(4) DEFAULT NULL,
    wattage int(3) DEFAULT NULL,
    ddr_gen INT(3) DEFAULT NULL,
    imagePath VARCHAR(255) DEFAULT NULL
);

LOCK TABLES memory WRITE;

INSERT INTO memory (part_name, price, contents, stock, wattage, ddr_gen, imagePath) VALUES 
('Corsair Vengeance LPX 16GB DDR4',89.99,'Memory module, Packaging',200,NULL,4,'1713479953664.jpg'),
('G.Skill Ripjaws V Series 32GB DDR4',159.99,'Memory module, Packaging',150,NULL,4,NULL),
('Crucial Ballistix 8GB DDR4',49.99,'Memory module, Packaging',300,NULL,4,NULL),
('Kingston HyperX Fury 16GB DDR4',79.99,'Memory module, Packaging',250,NULL,4,NULL),
('ADATA XPG GAMMIX D10 32GB DDR4',169.99,'Memory module, Packaging',100,NULL,4,NULL),
('Team T-FORCE VULCAN Z 16GB DDR4',84.99,'Memory module, Packaging',180,NULL,4,NULL),
('Patriot Viper Steel 16GB DDR4',94.99,'Memory module, Packaging',220,NULL,4,NULL),
('Corsair Dominator Platinum RGB 32GB DDR4',249.99,'Memory module, Packaging',120,NULL,4,NULL),
('Crucial Ballistix MAX 32GB DDR4',199.99,'Memory module, Packaging',150,NULL,4,NULL),
('G.Skill Trident Z RGB 16GB DDR4',109.99,'Memory module, Packaging',200,NULL,4,NULL);

UNLOCK TABLES;

DROP TABLE IF EXISTS gpus;
CREATE TABLE gpus(
    id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    part_name VARCHAR(255) DEFAULT NULL,
    price FLOAT(7, 2) DEFAULT NULL,
    contents VARCHAR(255) DEFAULT NULL,
    stock INT(4) DEFAULT NULL,
    wattage int(3) DEFAULT NULL,
    imagePath VARCHAR(255)DEFAULT NULL 
);

LOCK TABLES gpus WRITE;

INSERT INTO gpus (part_name, price, contents, stock, wattage, imagePath) VALUES 
('NVIDIA GeForce RTX 3080',699.99,'Graphics card, User manual',50,320,'1713479910358.jpg'),
('AMD Radeon RX 6800 XT',649.99,'Graphics card, User manual',60,300,NULL),
('NVIDIA GeForce RTX 3070',499.99,'Graphics card, User manual',70,220,NULL),
('AMD Radeon RX 6700 XT',479.99,'Graphics card, User manual',80,230,NULL),
('NVIDIA GeForce RTX 3060 Ti',399.99,'Graphics card, User manual',90,200,NULL),
('AMD Radeon RX 6900 XT',999.99,'Graphics card, User manual',40,330,NULL),
('NVIDIA GeForce RTX 3090',1499.99,'Graphics card, User manual',30,350,NULL),
('AMD Radeon RX 6600 XT',399.99,'Graphics card, User manual',100,160,NULL),
('NVIDIA GeForce RTX 3050 Ti',299.99,'Graphics card, User manual',120,130,NULL),
('AMD Radeon RX 6600',329.99,'Graphics card, User manual',110,150,NULL);

UNLOCK TABLES;

DROP TABLE IF EXISTS storage;
CREATE TABLE storage(
    id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    part_name VARCHAR(255) DEFAULT NULL,
    price FLOAT(5, 2) DEFAULT NULL,
    contents VARCHAR(255) DEFAULT NULL,
    stock INT(4) DEFAULT NULL,
    wattage int(3) DEFAULT NULL,
    imagePath VARCHAR(255) DEFAULT NULL
);

LOCK TABLES storage WRITE;

INSERT INTO storage (part_name, price, contents, stock, wattage, imagePath) VALUES 
('Samsung 970 EVO Plus 500GB NVMe SSD',89.99,'Storage device, User manual',150,NULL,'1713479999385.jpg'),
('Crucial MX500 1TB SATA SSD',109.99,'Storage device, User manual',200,NULL,NULL),
('Seagate BarraCuda 2TB HDD',59.99,'Storage device, User manual',300,NULL,NULL),
('Western Digital WD Blue SN550 1TB NVMe SSD',119.99,'Storage device, User manual',180,NULL,NULL),
('Samsung 870 QVO 2TB SATA SSD',219.99,'Storage device, User manual',100,NULL,NULL),
('ADATA SU760 512GB SATA SSD',59.99,'Storage device, User manual',250,NULL,NULL),
('Crucial P2 500GB NVMe SSD',59.99,'Storage device, User manual',220,NULL,NULL),
('Seagate IronWolf 4TB NAS HDD',109.99,'Storage device, User manual',150,NULL,NULL),
('Western Digital WD Black SN750 500GB NVMe SSD',79.99,'Storage device, User manual',200,NULL,NULL),
('Samsung 980 PRO 1TB NVMe SSD',179.99,'Storage device, User manual',120,NULL,NULL),
('Samsung 970 EVO Plus 500GB NVMe SSD',89.99,'Storage device, User manual',150,NULL,NULL),
('Crucial MX500 1TB SATA SSD',109.99,'Storage device, User manual',200,NULL,NULL),
('Seagate BarraCuda 2TB HDD',59.99,'Storage device, User manual',300,NULL,NULL),
('Western Digital WD Blue SN550 1TB NVMe SSD',119.99,'Storage device, User manual',180,NULL,NULL),
('Samsung 870 QVO 2TB SATA SSD',219.99,'Storage device, User manual',100,NULL,NULL),
('ADATA SU760 512GB SATA SSD',59.99,'Storage device, User manual',250,NULL,NULL),
('Crucial P2 500GB NVMe SSD',59.99,'Storage device, User manual',220,NULL,NULL),
('Seagate IronWolf 4TB NAS HDD',109.99,'Storage device, User manual',150,NULL,NULL),
('Western Digital WD Black SN750 500GB NVMe SSD',79.99,'Storage device, User manual',200,NULL,NULL),
('Samsung 980 PRO 1TB NVMe SSD',179.99,'Storage device, User manual',120,NULL,NULL);

UNLOCK TABLES;

DROP TABLE IF EXISTS psus;
CREATE TABLE psus(
    id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    part_name VARCHAR(255) DEFAULT NULL,
    price FLOAT(5, 2) DEFAULT NULL,
    contents VARCHAR(255) DEFAULT NULL,
    stock INT(4) DEFAULT NULL,
    wattage_delivered int(3) DEFAULT NULL,
    imagePath VARCHAR(255) DEFAULT NULL
);

LOCK TABLES psus WRITE;

INSERT INTO psus(part_name, price, contents, stock, wattage_delivered, imagePath) VALUES 
('EVGA SuperNOVA 650 G5, 80 Plus Gold 650W',99.99,'Power Supply Unit, User manual',150,650,'1713479621512.jpg'),
('Corsair RM750x, 80 Plus Gold 750W',129.99,'Power Supply Unit, User manual',120,750,'1713479675314.jpg'),
('Seasonic FOCUS GX-850, 80 Plus Gold 850W',159.99,'Power Supply Unit, User manual',100,850,NULL),
('Thermaltake Toughpower GF1 750W, 80 Plus Gold',119.99,'Power Supply Unit, User manual',130,750,NULL),
('Cooler Master MWE Gold 650 V2, 80 Plus Gold 650W',89.99,'Power Supply Unit, User manual',180,650,NULL),
('be quiet! Straight Power 11 Platinum 750W, 80 Plus Platinum',179.99,'Power Supply Unit, User manual',90,750,NULL),
('NZXT C Series CX750, 80 Plus Bronze 750W',79.99,'Power Supply Unit, User manual',200,750,NULL),
('EVGA 600 W1, 80 Plus White 600W',49.99,'Power Supply Unit, User manual',250,600,NULL),
('Corsair CV550, 80 Plus Bronze 550W',59.99,'Power Supply Unit, User manual',220,550,NULL),
('Antec NeoECO Gold ZEN 700W, 80 Plus Gold',99.99,'Power Supply Unit, User manual',190,700,NULL);

UNLOCK TABLES;

DROP TABLE IF EXISTS cases;
CREATE TABLE cases(
    id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    part_name VARCHAR(255) DEFAULT NULL,
    price FLOAT(5, 2) DEFAULT NULL,
    contents VARCHAR(255) DEFAULT NULL,
    stock INT(4) DEFAULT NULL,
    size VARCHAR(255) DEFAULT NULL,
    imagePath VARCHAR(255) DEFAULT NULL
);

LOCK TABLES cases WRITE;

INSERT INTO cases (part_name, price, contents, stock, size, imagePath) VALUES 
('NZXT H510 ATX Mid Tower Case', 69.99, 'Case, User manual', 100, 'ATX', '1713480030459.jpg'),
('Fractal Design Meshify C ATX Mid Tower Case', 89.99, 'Case, User manual', 80, 'ATX', NULL),
('Corsair 4000D Airflow ATX Mid Tower Case', 79.99, 'Case, User manual', 120, 'ATX', NULL),
('Phanteks Eclipse P400A ATX Mid Tower Case', 89.99, 'Case, User manual', 90, 'ATX', NULL),
('NZXT H210 Mini ITX Tower Case', 79.99, 'Case, User manual', 110, 'Mini ITX', NULL),
('Cooler Master MasterBox Q300L MicroATX Mini Tower Case', 49.99, 'Case, User manual', 150, 'Micro ATX', NULL),
('Thermaltake Versa H18 MicroATX Mini Tower Case', 54.99, 'Case, User manual', 130, 'Micro ATX', NULL),
('Fractal Design Focus G ATX Mid Tower Case', 59.99, 'Case, User manual', 140, 'ATX', NULL),
('Corsair iCUE 220T RGB Airflow ATX Mid Tower Case', 109.99, 'Case, User manual', 70, 'ATX', NULL),
('NZXT H510i ATX Mid Tower Case', 99.99, 'Case, User manual', 95, 'ATX', NULL);

UNLOCK TABLES;

DROP TABLE IF EXISTS users;
CREATE TABLE IF NOT EXISTS users (
    id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(255) DEFAULT NULL,
    password VARCHAR(255) DEFAULT NULL,
    number VARCHAR(255) DEFAULT NULL,
    card_num BIGINT(17) DEFAULT NULL,
    card_date VARCHAR(255) DEFAULT NULL,
    card_CVV INT(3) DEFAULT NULL ,
    street_address VARCHAR(255) DEFAULT NULL,
    city VARCHAR(255) DEFAULT NULL,
    home_state VARCHAR(255) DEFAULT NULL,
    zip_code VARCHAR(255) DEFAULT NULL,
    signed_in Bool DEFAULT NULL,
    build_id_owned VARCHAR(255) DEFAULT NULL
);
LOCK TABLES users WRITE;

INSERT INTO users (username, password, number, card_num, card_date, card_CVV, street_address, city, home_state, zip_code, signed_in, build_id_owned) VALUES 
('bhar133@lsu.edu', 'password', '630-222-2890', 1234567898765432,'0127', 123, '1234 somewhere st', 'Baton Rouge', 'LA', '70820', 0 ,NULL),
('lremon1@lsu.edu', 'Password', '730-321-8460', 6703459347685489, '1026', 345, '1234 somewhere st', 'Baton Rouge' ,'LA', '70820', 0 ,NULL),
('testuser', '12345', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

UNLOCK TABLES;

DROP TABLE IF EXISTS saved_builds;
CREATE TABLE IF NOT EXISTS saved_builds (
    id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(255) DEFAULT NULL,
    build_name VARCHAR(255) DEFAULT NULL,
    chip_selection VARCHAR(255) DEFAULT NULL,
    chip_amount INT(1) DEFAULT NULL,
    case_selection VARCHAR(255) DEFAULT NULL,
    motherboard VARCHAR(255) DEFAULT NULL,
    mother_amount INT(1) DEFAULT NULL,
    memorycard_selection VARCHAR(255) DEFAULT NULL,
    memory_amount INT(2) DEFAULT NULL,
    power_supply VARCHAR(255) DEFAULT NULL,
    power_amount INT(3) DEFAULT NULL,
    storage_part VARCHAR(255) DEFAULT NULL,
    storage_amount INT(1) DEFAULT NULL,
    comp_cooler VARCHAR(255) DEFAULT NULL,
    cooler_amount INT(1) DEFAULT NULL,
    videocard VARCHAR(255) DEFAULT NULL,
    video_amount INT(1) DEFAULT NULL
);

LOCK TABLES saved_builds WRITE;

INSERT INTO saved_builds (username, build_name, chip_selection, chip_amount, case_selection, motherboard, mother_amount, memorycard_selection,
memory_amount, power_supply, power_amount, storage_part, storage_amount, comp_cooler, cooler_amount, videocard, video_amount  ) VALUES 
('bhar133@lsu.edu', 'GOATED', 'Intel Core i7', 2, 'Phantekis NP7', 'ASUS ROG Strix Z690-E',
2, 'G.Skill Trident Z5 RGB Series 32GB', 3, 'CORSAIR RM750e', 15, 'Samsung SSD 990 Pro 1TB', 5, 'DeepCool AK620 Zero Dark',
100, 'GIGABYTE WINDFORCE RTX 4070', 2);

UNLOCK TABLES;